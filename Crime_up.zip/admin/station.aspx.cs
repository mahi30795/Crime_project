﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class admin_station : System.Web.UI.Page
{
    SqlConnection con;
    int step;
    int update;
    string ps;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db");
        con.Open();
        if (!IsPostBack)
        {
            load();
            

        }
       
    }
    protected void save()
    {
        
        
    }
    protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
    {
        
        
    }
    protected void next_Click(object sender, EventArgs e)
    {
        step = 2;
        MultiView1.SetActiveView(view2);
        label.InnerHtml = "Step 2/2";
        if (step == 2)
        {
            next.Text = "Submit";
            back.Enabled = true;
            next.CssClass = "btn btn-success";
            psname.Text = TextBox5.Text;
            next.Visible = false;
            submit.Visible = true;
        }
        
       
    }
    protected void back_Click(object sender, EventArgs e)
    {
        step = 1;
        MultiView1.SetActiveView(view1);
        back.Enabled = false;
        next.Text = "Next";
        next.CssClass = "btn";
        label.InnerHtml = "Step 1/2";
        next.Visible = true;
        submit.Visible = false;
    }
    protected void load(){
        TextBox1.Text = "";
                TextBox3.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                scs.InnerText = "";
                MultiView1.SetActiveView(view1);
                step = 1;
                
                oid.Text = "";
                oname.Text = "";
                age.Text = "";
                adr.Text = "";
                phn.Text = "";
                mail.Text = "";
                desig.Text = "";
                doj.Text = "";
                psname.Text = "";
                back.Enabled = false;
                next.Text = "Next";
                next.CssClass = "btn";
                label.InnerHtml = "Step 1/2";
                next.Visible = true;
                submit.Visible = false;
                DropDownList1.SelectedIndex = 0;
       
    }
    protected void submit_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex == 0)
        {
            derr.InnerHtml = "Please select district";
            MultiView1.SetActiveView(view1);

        }
        else
        {




            String sql = "insert into ps_tb values('" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox2.Text + "','" + DropDownList1.SelectedItem+ "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + oid.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            sql = "insert into login_tb values('" + TextBox1.Text + "','" + TextBox1.Text + "','ps')";
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            string gender;
            if (RadioButton1.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            if(update==2){
            
            sql = "insert into officers_tb values('" + oid.Text + "','" + oname.Text + "','" + age.Text + "','" + gender + "','" + adr.Text + "'," + Convert.ToInt64(phn.Text) + ",'" + mail.Text + "','"+doj.Text+"','" + desig.Text + "','" + TextBox1.Text + "' )";
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            }
            else{
                sql = "update ps_tb set in_charge='" + ps + "' where ps_id='" + ps +"'";
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                sql = "update officers_tb set name='" + oname.Text + "',age='" + age.Text + "',gender='" + gender + "',address='" + adr.Text + "',phone='" + phn.Text + "',mail='" + mail.Text + "',doj='" + doj.Text + "',desig='" + desig.Text + "',ps='" + TextBox1.Text + "'";
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                
            }
            
            scs.InnerText = "Success";

            if (scs.InnerText == "Success")
            {
                load();
            }
            Response.Write("<script>alert('Successully inserted')</script>");
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from ps_tb where ps_id='" + TextBox1.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            next.Enabled = false;
            psexist.InnerText = "Station with this ID already exists";
            
        }
        else
        {
            next.Enabled = true;
            psexist.InnerText = "";
        }
    }
    protected void TextBox15_TextChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from officers_tb where officer_id='" + oid.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            oexist.InnerText="Officer is already incharge of another police station "+ps+". Proceed to update.";

            oid.Text = dr[0].ToString();
            oname.Text = dr[1].ToString();
            age.Text = dr[2].ToString();
            if (dr[3].ToString() == "Male")
            {
                RadioButton1.Checked = true;
            }
            else
            {
                RadioButton2.Checked = true;
            }
            adr.Text = dr[4].ToString();
            phn.Text = dr[5].ToString();
            mail.Text = dr[6].ToString();
            doj.Text = dr[7].ToString();
            desig.Text = dr[8].ToString();
            ps = dr[9].ToString();
            
            update=1;

        }
        else
        {
            
            oname.Text = "";
            age.Text = "";
            adr.Text = "";
            phn.Text = "";
            mail.Text = "";
            desig.Text = "";
            doj.Text = "";
            update=2;
        }

    }
}