﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class admin_home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db");
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(*) from ps_tb", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            pcount.InnerHtml = dr[0].ToString();
        }
        dr.Close();
        con.Close();
    }
}