﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin_create_ps : System.Web.UI.Page
{
    SqlConnection con;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db");
        con.Open();
        if (!IsPostBack)
        {
            TextBox1.Text = ""; 
            TextBox3.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            scs.InnerText = "";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex == 0)
        {
            derr.InnerHtml = "Please select district";
        }
        else
        {


            String sql = "insert into ps_tb values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            sql = "insert into login_tb values('" + TextBox1.Text + "','" + TextBox1.Text + "','ps')";
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            scs.InnerText = "Success";
        }
    }
}