﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_adminmaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("../index.aspx");
            }
        }

    }
    protected void lgout(object sender, EventArgs e)
    {
        Session["user"] = null;
        Response.Redirect("../index.aspx");
    }
    
}
