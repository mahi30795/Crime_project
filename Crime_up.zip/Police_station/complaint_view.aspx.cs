﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class Police_station_complaint_view : System.Web.UI.Page
{
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        con=new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db");
        con.Open();
        
        
        if (!IsPostBack)
        {
            SqlCommand cmd=new SqlCommand("select * from complaint_tb where complaint_id="+Request.QueryString["id"]+"",con);
            SqlDataReader dr=cmd.ExecuteReader();
            if(dr.Read()){
                subject.Text = dr[1].ToString();
            }
            
        }
    }
}