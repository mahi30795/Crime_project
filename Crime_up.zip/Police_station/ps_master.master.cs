﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Police_station_MasterPage : System.Web.UI.MasterPage
{
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db");
        con.Open();
        if (!IsPostBack)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("../index.aspx");
            }
            SqlCommand cmd = new SqlCommand("select name from ps_tb where ps_id='" + Session["user"] + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                title.InnerText = dr[0].ToString();
            }
            dr.Close();
        }
        con.Close();
    }
    protected void lgout(object sender, EventArgs e)
    {
        Session["user"] = null;
        Response.Redirect("../index.aspx");
    }
}
