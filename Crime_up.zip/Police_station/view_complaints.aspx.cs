﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Police_station_view_complaints : System.Web.UI.Page
{
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("server=.;uid=sa;pwd=macfast@1;database=crime_db;");
        con.Open();
        if (!IsPostBack)
        {
            SqlCommand cmd = new SqlCommand("select * from complaint_tb", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {

            }
        }
    }
    protected void gridMembersList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "More")
        {
            int id = Convert.ToInt32(e.CommandArgument.ToString());
            
           
            Response.Redirect("complaint_view.aspx?id="+id+"");
        }
    }
}